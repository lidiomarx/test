import numpy as np

import sqlalchemy
from sqlalchemy.ext.automap import automap_base
from sqlalchemy.orm import Session
from sqlalchemy import create_engine, func

import datetime as dt

from flask import Flask, jsonify


#################################################
# Database Setup
#################################################
engine = create_engine("sqlite:///Resources/hawaii.sqlite")

# reflect database
Base = automap_base()
# reflect the tables
Base.prepare(engine, reflect=True)

# Save reference to the table
Measurement = Base.classes.measurement
Station = Base.classes.station

# Create our session (link) from Python to the DB
session = Session(engine)

#################################################
# Flask Setup
#################################################
app = Flask(__name__)


#################################################
# Flask Routes
#################################################

@app.route("/")
def welcome():
    """List all available api routes."""
    return (
        f"Available Routes:<br/>"
        f"/api/v1.0/precipitation<br/>"
        f"/api/v1.0/stations</br>"
        f"api/v1.0/tobs</br>"
        f"/api/v1.0/start</br>"
        f"/api/v1.0/start/end</br>"
    )


@app.route("/api/v1.0/precipitation")
def get_precipitation():
    # Query total precipitation by date
    results = session.query(Measurement.date,func.sum(Measurement.prcp)). \
        group_by(Measurement.date).all()

    # Create dict
    d = { date:prcp for date, prcp in results }

    return jsonify(d)


@app.route("/api/v1.0/stations")
def get_stations():
    # Get stations
    results = session.query(Station.station).all()
    return jsonify(list(np.ravel(results)))

@app.route("/api/v1.0/tobs")
def get_tobs():

    # get the last date and substract 1 year
    last_date_str = session.query(Measurement.date).order_by(Measurement.date.desc()).first()[0]
    last_date = dt.datetime.strptime(last_date_str,'%Y-%m-%d')

    # Calculate the date 1 year ago from the last data point in the database
    first_date = dt.date(year=last_date.year-1,month=last_date.month,day=last_date.day)

    # Perform a query to retrieve the date and avg tobs per date
    results = session.query(Measurement.date,func.avg(Measurement.tobs)).\
    filter(Measurement.date >= first_date). \
    group_by(Measurement.date).order_by(Measurement.date).all()

    dates, tobs = zip(*results) # unzip

    return jsonify(tobs)

@app.route("/api/v1.0/<start>")
def get_tobs_by_date(start):
    # Return a JSON list of the minimum temperature, the average temperature,
    # and the max temperature for a given start or start-end range
    results = session.query(func.min(Measurement.tobs), func.avg(Measurement.tobs), func.max(Measurement.tobs)).\
        filter(Measurement.date >= start).all()[0]

    mint, avgt, maxt = results

    return jsonify([mint, avgt, maxt])

@app.route("/api/v1.0/<start>/<end>")
def get_tobs_by_date2(start, end):
    # Return a JSON list of the minimum temperature, the average temperature,
    # and the max temperature for a given start or start-end range
    results = session.query(func.min(Measurement.tobs), func.avg(Measurement.tobs), func.max(Measurement.tobs)).\
        filter(Measurement.date >= start).filter(Measurement.date <= end).all()[0]

    mint, avgt, maxt = results

    return jsonify([mint, avgt, maxt])


if __name__ == '__main__':
    app.run(debug=True)